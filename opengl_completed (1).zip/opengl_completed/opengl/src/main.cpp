#define GLEW_STATIC

#include "error.h"
#include "Light.h"
#include "freeLookCamera.h"
#include "events.h"
#include "openglFunctions.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "Noise_map.h"



using namespace std;

freeCamera Camera;

Light scene_light;

Mouse_input Manager;

bool is_perspective = true;

void Uinput(float ts)
{
	if (Manager.mouse_scroll_return().increase)
	{
		Camera.MovementSpeed += 1.25f;
	}

	else if (Manager.mouse_scroll_return().decrease)
	{
		Camera.MovementSpeed -= 1.25f;
	}

	if (Manager.mouseMoved())
	{
		Camera.ProcessMouseMovement(Manager.getCusorPosition()[0], Manager.getCusorPosition()[1]);
	}
}


void display(GLsizei count)
{
	GLcall(glDrawArrays(GL_TRIANGLES, 0, count));
}

void displayIndex(GLsizei count)
{
	GLcall(glDrawElements(GL_TRIANGLES, count, GL_UNSIGNED_INT, nullptr));
}

void display(GLsizei start, GLsizei count)
{
	// draw triangles starting from index 0 and
	// using 3 indices
	GLcall(glDrawArrays(GL_TRIANGLE_STRIP, start, count));
}

// main function
int main(int argc, char** argv)
{
	//............................................................................
	if (!glfwInit()) {
		std::cout << "initialization failed!" << std::endl;
		return 0;
	}
	//................................................................................
	GLFWwindow* m_window = glfwCreateWindow(1280, 720, "opengl", nullptr, nullptr);

	int max, min, r;
	glfwGetVersion(&max, &min, &r);
	//..............................................................................
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_COMPAT_PROFILE);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, max);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, min);

	std::cout << "version >> " << max << "." << min << std::endl;
	//...............................................................
	glfwMakeContextCurrent(m_window);

	glfwSetErrorCallback((GLFWerrorfun)[](int error_code, const char* description) {
		fprintf(stderr, "Error: %s\n", description);
		});

	glfwSetInputMode(m_window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
	//.............................................................
	if (glewInit() != GLEW_OK)
	{
		std::cout << "error opengl loader not initialized" << std::endl;
	}

	//...........................................................
	//std::cout << glGetString(GL_VERSION) << std::endl;
	Manager = Mouse_input(m_window);
	init();

	Camera.Position = glm::vec3(19.0f,  76.0f,  15.0f);
	
	//...........................................................
	glm::mat4 projection = glm::infinitePerspective(glm::radians(60.0f), 16.0f/ 9.0f, 0.1f);
	glm::mat4 model = glm::mat4(1.0f), view = glm::mat4(1.0f), spotModel = glm::mat4(1.0f);
	//.............................................................

	//.........................................................
	scene_light = Light(glm::vec3(0.9f, 0.9f, 0.9f), "light[0]", 10500.0f, 0.25f, 15250.51f);
	
	scene_light.set_position(glm::vec3(80.0f, 200.0f, 0.0f));
	scene_light.set_Spotdirection(glm::vec3(-50.0f, -200.0f, -50.0f));
	scene_light.set_spotlight_cutoff(glm::cos(3.14f / 2.0f));
	scene_light.set_spotlight_innercutoff(glm::cos(3.14f / 10.0f));
	scene_light.set_attenuation_constants(4.0f, 1.0f, 0.5f, 0.44f);

	//set s projection /////////////////////////////////////////////
	general_program.setUniformMat4("projection", projection);
	general_program.Bind();

	float deltaTime, currentFrame, lastFrame = 0;

	float theta = 0.0f;
	glm::vec3 lightPos = glm::vec3(glm::sin(theta) * 150, 100, glm::cos(theta) * 150);


	opengl2Dtexture Keys = opengl2Dtexture("asset/Keys.jpg");
	opengl2Dtexture Jotter = opengl2Dtexture("asset/jotter.jpg");
	opengl2Dtexture Fora = opengl2Dtexture("asset/Flora.jpg");
	opengl2Dtexture White = opengl2Dtexture("asset/White.png");
	opengl2Dtexture Fabric = opengl2Dtexture("asset/Green_fabric.jpg");
	opengl2Dtexture Mug = opengl2Dtexture("asset/Mug_tex.jpg");
	opengl2Dtexture Coffee_brown = opengl2Dtexture("asset/Coffee.png");

	glm::vec3 scale;
	glm::vec3 position;


	Noise_geometry Thorn_ = Noise_geometry(10.0f, 15.3f, 1.0f, 100.0f, 1.0f);

	while (!glfwWindowShouldClose(m_window))
	{
		currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		//Mouse_input////////////////////////////////////////
		Uinput(deltaTime);

		if (glfwGetKey(m_window, GLFW_KEY_A) == GLFW_PRESS)
		{
			Camera.ProcessKeyboard(Camera_Movement::LEFT, deltaTime * 100);
		}
		else if (glfwGetKey(m_window, GLFW_KEY_D) == GLFW_PRESS)
		{
			Camera.ProcessKeyboard(Camera_Movement::RIGHT, deltaTime * 100);
		}

		else if (glfwGetKey(m_window, GLFW_KEY_W))
		{
			Camera.ProcessKeyboard(Camera_Movement::FORWARD, deltaTime * 100);
		}

		else if (glfwGetKey(m_window, GLFW_KEY_S))
		{
			Camera.ProcessKeyboard(Camera_Movement::BACKWARD, deltaTime * 100);
		}

		else if (glfwGetKey(m_window, GLFW_KEY_Q))
		{
			Camera.ProcessKeyboard(Camera_Movement::UP, deltaTime * 100);
		}

		else if (glfwGetKey(m_window, GLFW_KEY_E))
		{
			Camera.ProcessKeyboard(Camera_Movement::DOWN, deltaTime * 100);
		}

		else if (glfwGetKey(m_window, GLFW_KEY_P))
		{
			is_perspective = !is_perspective;
		}


		//sets view///////////////////////////
		view = Camera.GetViewMatrix();
		projection = (is_perspective ? glm::infinitePerspective(glm::radians(60.0f), 16.0f / 9.0f, 0.1f) : glm::orthoRH(-105.0f, 105.0f, -105.0f, 105.0f, 0.01f, 10000.0f));
		
		if (glfwGetKey(m_window, GLFW_KEY_ESCAPE))
		{
			break;
		}

		//set light uniforms
		scene_light.render( Camera.Position,  general_program.getRendererId(), false, true );
		
		//sets view matrix ///////////////////////////
		general_program.Bind();
		general_program.setUniformMat4("view", view);
		general_program.setUniformMat4("projection", projection);


		GLcall(glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT));
		GLcall(glClearColor(0.5f, 0.5f, 0.5f, 1.0f));

		GLcall(glViewport(0, 0, 1280, 720));
		{
			//sets texture sampler
			general_program.Bind();
			Fora.bindTextureToSlot(Fora.GetTextureSlot());
			White.bindTextureToSlot(3);
			general_program.setTextureSampler("_MainTex", Fora.GetTextureSlot());
			general_program.setTextureSampler("texture_2", White.GetTextureSlot());

			//sets model matrix ////////////////////////////
			//model transformation/////////////////////////////////////				

			//sets model and color uiniforms
			general_program.setUniformMat4("projection", projection);
			general_program.setUniformMat4("model", glm::scale(glm::mat4(1.0f), glm::vec3(400.0f, 1.0f, 400.0f)));
			general_program.setUniformMat4("view", view);

			planeBuffer.Bind();
			planeVao.Bind();
			display(36);
		}


		{
			VAO.Bind();
			ibo.Bind();
			//tip of prncils

			scale = glm::vec3(0.6f, 0.6f, 3.5f);
			position = glm::vec3(0.0f, 1.0f, 30.0f);

			general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), position + glm::vec3(0.0f, 0.0f, -9.5f) )
				* glm::rotate(glm::mat4(1.0f), glm::radians(180.0f), glm::vec3(1, 0, 0)) *
				glm::scale(glm::mat4(1.0f), scale));

			general_program.setUniformVec3("color", glm::vec3(0.0f));
			

			Fabric.bindTextureToSlot(2);
			Keys.bindTextureToSlot(3);
			general_program.setTextureSampler("_MainTex", Keys.GetTextureSlot());
			general_program.setTextureSampler("texture_2", Fabric.GetTextureSlot());

			displayIndex(cylinder.getIndexCount());

			//next pen
			glm::vec3 pos_2 = position + glm::vec3(10.0f, 0.0f, 10.0f);
			glm::vec3 sc_2 = scale;

			general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), pos_2 + glm::vec3(0.0f, 0.0f, -9.50f))
				* glm::rotate(glm::mat4(1.0f), glm::radians(180.0f), glm::vec3(1, 0, 0)) *
				glm::scale(glm::mat4(1.0f), sc_2));

			displayIndex(cylinder.getIndexCount());

			//next pen3
			glm::vec3 pos_3 = position + glm::vec3(80.0f, 0.0f, 10.0f);
			glm::vec3 sc_3 = scale;

			general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), pos_3 + glm::vec3(0.0f, 0.0f, -9.50f))
				* glm::rotate(glm::mat4(1.0f), glm::radians(180.0f), glm::vec3(1, 0, 0)) *
				glm::scale(glm::mat4(1.0f), sc_3));

			displayIndex(cylinder.getIndexCount());

			//MUG 

			Mug.bindTextureToSlot(2);
			White.bindTextureToSlot(3);
			general_program.setTextureSampler("_MainTex", Mug.GetTextureSlot());
			general_program.setTextureSampler("texture_2", White.GetTextureSlot());

			general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(-50.0f, 10.0f, -3.50f))
				* glm::rotate(glm::mat4(1.0f), glm::radians(270.0f), glm::vec3(1, 0, 0))*
				glm::scale(glm::mat4(1.0f), glm::vec3(15.0f, 15.0f, 50.0f) ));

			displayIndex(cylinder.getIndexCount());
		}
		
		{						
			VAO_2.Bind();
			ibo_2.Bind();
			//body of pencils
			Fabric.bindTextureToSlot(2);
			White.bindTextureToSlot(3);
			general_program.setTextureSampler("_MainTex", Fabric.GetTextureSlot());
			general_program.setTextureSampler("texture_2", White.GetTextureSlot());


			general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), position)
				* glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(1, 0, 0)) *
				glm::scale(glm::mat4(1.0f), scale + glm::vec3(0.35f, 0.35f, 14.5f) ));

			general_program.setUniformVec3("color", glm::vec3(0.0f));

			displayIndex(cylinder_2.getIndexCount());
			
			//next pen
			glm::vec3 pos_2 = position + glm::vec3(10.0f, 0.0f, 10.0f);
			glm::vec3 sc_2 = scale;

			general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), pos_2)
				* glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(1, 0, 0)) *
				glm::scale(glm::mat4(1.0f), sc_2 + glm::vec3(0.35f, 0.35f, 14.5f)));

			//next Pen
			displayIndex(cylinder_2.getIndexCount());


			//next pen3
			glm::vec3 pos_3 = position + glm::vec3(80.0f, 0.0f, 10.0f);
			glm::vec3 sc_3 = scale;

			general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), pos_3)
				* glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(1, 0, 0))*
				glm::scale(glm::mat4(1.0f), sc_3 + glm::vec3(0.35f, 0.35f, 14.5f)));

			displayIndex(cylinder_2.getIndexCount());
		}

		//NBOOKS
		{
			general_program.Bind();
			planeVao.Bind();

			float height = 20.0f;
			float angle = 45.0f;

			Jotter.bindTextureToSlot(2);
			White.bindTextureToSlot(3);
			general_program.setTextureSampler("_MainTex", Jotter.GetTextureSlot());
			general_program.setTextureSampler("texture_2", White.GetTextureSlot());

			//books top
				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(40.0f, 1.0f, -30.0f)) *
					glm::rotate(glm::mat4(1.0f), glm::radians(5.0f), glm::vec3(0, -1, 0)) *
					glm::scale(glm::mat4(1.0f), glm::vec3(60.2f, 2.0f, 85.2f)));

				general_program.setUniformVec3("color", glm::vec3(0.0f));

				display(36);

				//book
				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(40.0f, 0.2f, -30.0f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(1.0f), glm::vec3(0, 1, 0)) * glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f)) *
					glm::scale(glm::mat4(1.0f), glm::vec3(60.2f, 2.0f, 85.2f)));

				general_program.setUniformVec3("color", glm::vec3(1.0f, 0.6f, 0.3f));

				display(36);

				//keyboard

				Keys.bindTextureToSlot(2);
				White.bindTextureToSlot(3);
				general_program.setTextureSampler("_MainTex", Keys.GetTextureSlot());
				general_program.setTextureSampler("texture_2", White.GetTextureSlot());

				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(40.0f, 0.2f, -140.0f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(15.0f), glm::vec3(0, 1, 0))* glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f))*
					glm::scale(glm::mat4(1.0f), glm::vec3(80.2f, 3.0f, 60.2f)));

				general_program.setUniformVec3("color", glm::vec3(0.0f));

				display(36);

				general_program.setUniformVec3("color", glm::vec3(1.0f));


				//GLASSES
				//top
				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(40.0f, 0.5f, 40.0f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(0, 1, 0))* glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f))*
					glm::scale(glm::mat4(1.0f), glm::vec3(15.0f, 1.5f, 0.5f)));

				general_program.setUniformVec3("color", glm::vec3(0.3f));

				display(36);


				//////////lens hold
				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(40.0f, 0.5f, 41.5f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(0, 1, 0))* glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f))*
					glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 1.5f, 2.5f)));


				display(36);


				//////////lens hold
				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(32.5f, 0.5f, 41.5f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(0, 1, 0))* glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f))*
					glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 1.5f, 2.5f)));


				display(36);

				//////////lens hold
				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(47.5f, 0.5f, 41.5f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(0, 1, 0))* glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f))*
					glm::scale(glm::mat4(1.0f), glm::vec3(0.5f, 1.5f, 2.5f)));


				display(36);

				//////////lens hold
				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(44.f, 0.5f, 43.0f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(0, 1, 0))* glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f))*
					glm::scale(glm::mat4(1.0f), glm::vec3(7.5f, 1.5f, 0.5f)));


				display(36);

				//////////lens hold
				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(36.f, 0.5f, 43.0f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(0, 1, 0))* glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f))*
					glm::scale(glm::mat4(1.0f), glm::vec3(-7.5f, 1.5f, 0.5f)));


				display(36);

				//Arms
				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(37.0f, -8.0f, 40.0f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(-45.0f), glm::vec3(0, 0, 1))* glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f))*
					glm::scale(glm::mat4(1.0f), glm::vec3(15.0f, 1.0f, 0.1f)));

				display(36);

				general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(32.0f, 20.0f, 41.0f))*
					glm::rotate(glm::mat4(1.0f), glm::radians(45.0f), glm::vec3(0, 0, 1))* glm::translate(glm::mat4(1.0f), glm::vec3(-20.0f, 0.2f, 0.0f))*
					glm::scale(glm::mat4(1.0f), glm::vec3(15.0f, 1.0f, 0.1f)));

				display(36);
		}

		//buds ??
		{
			VAO.Bind();
			vbo.Bind();
		
			general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(80.0f, 4.0f, -120.0f))
				* glm::rotate(glm::mat4(1.0f), glm::radians(90.0f), glm::vec3(1, 0, 0)) *
				glm::scale(glm::mat4(1.0f), glm::vec3(2.0f, 2.0f, 3.0f)));

			general_program.setUniformVec3("color", glm::vec3(0.0f));

			display(cylinder.getVertexCount(), obj.getCount());


			// HANDLE

			White.bindTextureToSlot(3);
			general_program.setTextureSampler("_MainTex", White.GetTextureSlot());
			general_program.setTextureSampler("texture_2", White.GetTextureSlot());

			general_program.setUniformMat4("model", glm::translate(glm::mat4(1.0f), glm::vec3(-40.0f, 15.0f, -4.50f))
				* glm::rotate(glm::mat4(1.0f), glm::radians(-80.0f), glm::vec3(0, 0, 1))*
				glm::scale(glm::mat4(1.0f), glm::vec3(7.0f, 7.0f, 3.0f)));

			general_program.setUniformVec3("color", glm::vec3(0.0f));

			display(cylinder.getVertexCount(), obj.getCount() / 2);
		}

		//Brown OBJ
		{
			glm::mat4 model = glm::translate(glm::mat4(1.0f), glm::vec3(-40.0f, -3.0f, 60.50f))
				* glm::rotate(glm::mat4(1.0f), glm::radians(0.0f), glm::vec3(0, 0, 1)) *
				glm::scale(glm::mat4(1.0f), glm::vec3(10.0f, 40.0f, 15.0f));

			Coffee_brown.bindTextureToSlot(6);

			Thorn_.BindVao();
			Thorn_.Render(model, view, projection, Coffee_brown.GetTextureSlot());
		}


		model = glm::mat4(1.0f);


		glfwSwapBuffers(m_window);
		//polls all Mouse_input recorded
		glfwPollEvents();
	}

	return 0;
}

