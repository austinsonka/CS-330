#pragma once

#include <vector>

#include <glm/glm.hpp>

#include "renderer/buffers.h"
#include <iostream>

#include "../stb_image/stb_image.h"
#include "renderer/opengleShader.h"

#include "perlin.h"

class Noise_geometry
{
public:
	Noise_geometry(const char* imagePath, float HeightScale = 0.5f)
	{
		height_scale = HeightScale;
		int width, height;
		stbi_set_flip_vertically_on_load(true);
		unsigned char* data = stbi_load(imagePath, &width, &height, &NR, 0);

		unsigned bytePerPixel = NR;

		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				unsigned char* offset = data + (j + width * i) * bytePerPixel;

				unsigned char y = offset[0];

				vertices.push_back((-height / 2.0f + i) / (float)height);

				vertices.push_back(((float)(int)y * height_scale / 256.0f));

				vertices.push_back((-width / 2.0f + j) / (float)width);


				float tex_x = (float)j / ((float)width / 8.0f); //this works well to repeat the texture
				float tex_y = (float)i / ((float)height / 8.0f); //this works well to repeat the texture

				texture_coords.push_back(tex_x);
				texture_coords.push_back(tex_y);
			}
		}

		strip_res = 1;
		for (unsigned i = 0; i < height - 1; i += strip_res)
		{
			for (unsigned j = 0; j < width; j += strip_res)
			{
				for (unsigned k = 0; k < 2; k++)
				{
					indices.push_back(j + width * (i + k * strip_res));
				}
			}
		}
		shader = new openglShader("asset/heightmap_vertex_shader.glsl",
			"asset/heightmap_fragment_shader.glsl",
			"Main_shader");

		stbi_image_free(data);

		int numElements = Size_of_elements(width, height);

		GLcall(glGenVertexArrays(1, &VAO));
		GLcall(glBindVertexArray(VAO));

		Tex_data = new vertexBuffer(&(texture_coords[0]), texture_coords.size() * sizeof(float));

		Vertex_data = new vertexBuffer(&(vertices[0]), vertices.size() * sizeof(float));

		Index_data = new IndexBuffer(&(indices[0]), indices.size() * sizeof(unsigned));

		Vertex_data->Bind();
		GLcall(glVertexAttribPointer(0, 3, GL_FLOAT, false, 3 * sizeof(float), 0));
		GLcall(glEnableVertexAttribArray(0));

		Tex_data->Bind();
		GLcall(glVertexAttribPointer(1, 2, GL_FLOAT, false, 2 * sizeof(float), 0));
		GLcall(glEnableVertexAttribArray(1));

		Index_data->Bind();


	}

	Noise_geometry(int width_, float roughness_, float octaves_, int max_height_, float HeightScale);

	~Noise_geometry()
	{
		delete Vertex_data;
		delete Index_data;
		delete shader;
		delete Tex_data;
	}


	void Render(const glm::mat4& model, const glm::mat4& view, const glm::mat4& projection, int slot = 0);

	openglShader* getShader() { return shader; }

	void BindVao();

private:
	int NR;

	int Triangles_per_strip;

	int strip_res;

	int num_of_strips;

	float height_scale;

	unsigned int VAO;
	vertexBuffer* Vertex_data;
	
	vertexBuffer* Tex_data;

	IndexBuffer* Index_data;

	openglShader* shader;

	int Size_of_elements(int width, int height);

	std::vector<float> texture_coords;
	
	std::vector<float> vertices;

	std::vector<unsigned> indices;

};