#include "Noise_map.h"



Noise_geometry::Noise_geometry(int width_, float roughness_, float octaves_, int max_height_, float HeightScale)
{
	Perlin_Noise Noise = Perlin_Noise(width_, roughness_, octaves_, max_height_);

	{
		height_scale = HeightScale;
		int width = width_, height = width_;
		//stbi_set_flip_vertically_on_load(true);
		//unsigned char* data = stbi_load(imagePath, &width, &height, &NR, 0);

		unsigned bytePerPixel = NR;

		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				//unsigned char* offset = data + (j + width * i) * bytePerPixel;

				unsigned char y = Noise.heights.at(j * width + i);

				vertices.push_back((-height / 2.0f + i) / (float)height);

				vertices.push_back(((float)(int)y * height_scale / 256.0f));

				vertices.push_back((-width / 2.0f + j) / (float)width);

				
				float tex_x = (float)j / ((float)width /  8.0f); //this works well to repeat the texture
				float tex_y = (float)i / ((float)height / 8.0f); //this works well to repeat the texture

				texture_coords.push_back(tex_x);
				texture_coords.push_back(tex_y);
			}
		}

		strip_res = 1;
		for (unsigned i = 0; i < height - 1; i += strip_res)
		{
			for (unsigned j = 0; j < width; j += strip_res)
			{
				for (unsigned k = 0; k < 2; k++)
				{
					indices.push_back(j + width * (i + k * strip_res));
				}
			}
		}
		shader = new openglShader("asset/heightmap_vertex_shader.glsl",
			"asset/heightmap_fragment_shader.glsl", "asset/geometry.glsl",
			"Main_shader");

		//stbi_image_free(data);

		int numElements = Size_of_elements(width, height);

		GLcall(glGenVertexArrays(1, &VAO));
		GLcall(glBindVertexArray(VAO));

		Tex_data = new vertexBuffer(&(texture_coords[0]), texture_coords.size() * sizeof(float));
		
		Vertex_data = new vertexBuffer(&(vertices[0]), vertices.size() * sizeof(float));

		Index_data = new IndexBuffer(&(indices[0]), indices.size() * sizeof(unsigned));

		Vertex_data->Bind();
		GLcall(glVertexAttribPointer(0, 3, GL_FLOAT, false, 3 * sizeof(float), 0));
		GLcall(glEnableVertexAttribArray(0));

		Tex_data->Bind();
		GLcall(glVertexAttribPointer(1, 2, GL_FLOAT, false, 2 * sizeof(float), 0));
		GLcall(glEnableVertexAttribArray(1));

		Index_data->Bind();

	}
}

void Noise_geometry::Render(const glm::mat4& model, const glm::mat4& view, const glm::mat4& projection, int slot)
{
	BindVao();
	Index_data->Bind();

	shader->Bind();

	shader->Bind();
	shader->setUniformFloat("Height", height_scale);

	shader->setUniformMat4("model", model);

	shader->setUniformMat4("view", view);

	shader->setUniformMat4("projection", projection);
	
	shader->setTextureSampler("map", slot);

	GLint pointLightPosLoc = glGetUniformLocation(shader->getRendererId(), "pointLight.position");
	glUniform3f(pointLightPosLoc, 80.0f, 200.0f, 0.0f); // Position of the light (30 units above the mesh)

	GLint pointLightAmbientLoc = glGetUniformLocation(shader->getRendererId(), "pointLight.ambient");
	glUniform3f(pointLightAmbientLoc, 0.2f, 0.2f, 0.2f); // Ambient color of the light (red)

	GLint pointLightDiffuseLoc = glGetUniformLocation(shader->getRendererId(), "pointLight.diffuse");
	glUniform3f(pointLightDiffuseLoc, 0.6f, 0.6f, 0.6f); // Diffuse color of the light (red)

	GLint pointLightSpecularLoc = glGetUniformLocation(shader->getRendererId(), "pointLight.specular");
	glUniform3f(pointLightSpecularLoc, 1.0f, 1.0f, 1.0f); // Specular color of the light (white)


	for (unsigned S = 0; S < num_of_strips; S++)
	{
		GLcall(glDrawElements(GL_TRIANGLE_STRIP, Triangles_per_strip + 2, GL_UNSIGNED_INT, (void*)(sizeof(unsigned) * (Triangles_per_strip + 2) * S)));
	}
}

int Noise_geometry::Size_of_elements(int width, int height) {
	strip_res = 1;
	num_of_strips = (height - 1) / strip_res;

	Triangles_per_strip = (width / strip_res) * 2 - 2;

	return num_of_strips;
}



void Noise_geometry::BindVao()
{
	GLcall(glBindVertexArray(VAO));
}

